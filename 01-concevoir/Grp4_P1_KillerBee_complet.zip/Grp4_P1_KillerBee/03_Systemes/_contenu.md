# 03_Systemes – Responsable : Oumayma

- [ ] Grp4_Inventaire_Materiel-Logiciel_v1.xlsx : machines physiques et VM (CPU, RAM, disque, IP, rôle) + versions OS, services et logiciels
- [ ] Grp4_Architecture-AD_v1.pdf : OU, groupes (dont role_rd, role_test, role_prod), comptes de service SQL, GPO

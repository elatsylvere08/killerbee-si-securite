# 02_Reseau – Responsables : Orphélia et Sylvère

- [ ] Grp4_Schema-Reseau_Physique_v1.pdf (+ source .drawio)
- [ ] Grp4_Schema-Reseau_Logique_v1.pdf (+ source .drawio)
- [x] Grp4_Plan-Adressage_Matrice-Flux_v2.pdf (serveur Proxmox : 192.168.137.4)
- [ ] Grp4_Config_Switch-2960.txt : sortie de `show running-config`
- [ ] Grp4_Config_pfSense_AAAA-MM-JJ.xml : export Diagnostics > Backup & Restore
- [ ] Grp4_pfSense_Captures.pdf : interfaces, alias, règles par zone, DHCP

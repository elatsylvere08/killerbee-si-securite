# 04_Applicatif – Responsables : Kris et Cyrine

- [ ] sources/ : code de l'application (front, middleware, proxy, services)
- [ ] sql/ : scripts de création (schémas SCH_RD, SCH_TEST, SCH_PROD, tables, rôles, logins, sauvegardes)
- [ ] Grp4_MCD_v1.pdf
- [ ] Grp4_UML_v1.pdf : cas d'utilisation, classes, séquence du flux chiffré, composants
- [ ] Grp4_Dossier-Technique_v1.pdf : stratégie de sauvegarde SQL, choix des schémas, algorithme de chiffrement, RGPD
- [x] Grp4_Matrice-Flux_APP-BDD_v2.pdf : flux applicatifs et SQL Server

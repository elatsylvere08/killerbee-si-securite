# Livrable Phase 1 – Concevoir | Groupe 4 – SI KillerBee

**Option Cybersécurité – CESI | Blue Team**
Équipe : Sylvère (chef de projet, pfSense, Wazuh), Orphélia (réseau), Oumayma (systèmes),
Kris (développement), Cyrine (conception, UML/MCD).

## Contenu de l'archive

| Dossier | Contenu | Livrables du sujet |
|---|---|---|
| 01_Pilotage | Plan de pilotage (Kanban GitHub), journal des écarts et décisions | Plan de pilotage |
| 02_Reseau | Schéma réseau, plan d'adressage, matrice des flux, configurations switch et pfSense | Schéma réseau, plan d'adressage IP, configurations des matériels réseau |
| 03_Systemes | Inventaire matériel et logiciel, architecture Active Directory | Configurations matérielles, versions OS/services/logiciels, architecture AD |
| 04_Applicatif | Codes sources, scripts SQL, UML, MCD, dossier technique de justification | Codes sources, modélisations UML et MCD |
| 05_GitLab | Référence du dépôt et preuves d'utilisation | Référence du dépôt GitLab |
| 06_Journaux | Fiche des sources de journaux centralisées (Wazuh) | Liste des sources de journaux |

## Écarts majeurs par rapport au sujet (détaillés dans 01_Pilotage)

- Stormshield SN210 sans licence : remplacé par **pfSense CE 2.7.2** virtualisé sur Proxmox.
- Matériel réseau disponible : un seul switch Catalyst 2960, pas de routeur ; le routage inter-VLAN est assuré par pfSense.
- Messagerie : **Postfix** au lieu d'Exchange.

## Conventions

- Fichiers nommés `Grp4_<Sujet>_v<version>.<ext>`, dates au format AAAA-MM-JJ.
- **Aucun mot de passe** dans cette archive : les secrets sont conservés dans le coffre KeePassXC de l'équipe.

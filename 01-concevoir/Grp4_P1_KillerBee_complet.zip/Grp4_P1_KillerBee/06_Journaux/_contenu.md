# 06_Journaux – Responsable : Sylvère

- [x] Grp4_Sources-Journaux_Wazuh_v1.pdf : export de la fiche « Sources de journaux centralisées »
- [ ] Grp4_Wazuh_Captures.pdf : agents actifs, alertes AD-DC01, MAIL, VOIP, événements pfSense

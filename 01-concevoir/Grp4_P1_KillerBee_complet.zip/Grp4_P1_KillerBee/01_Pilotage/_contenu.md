# 01_Pilotage – Responsable : Sylvère

- [ ] Grp4_Pilotage_Lien-Kanban.txt : lien en lecture seule du projet GitHub (organisation A5-grp4-KillerBee)
- [ ] Grp4_Kanban_Capture_AAAA-MM-JJ.png : capture datée du tableau (début et fin de phase)
- [x] Grp4_Journal-Ecarts_v1.pdf : écarts prévu/réalisé et décisions prises

# 05_GitLab – Responsable : Kris

- [ ] Grp4_GitLab_Reference.txt : URL et nom du projet
- [ ] Grp4_GitLab_Captures.pdf : graphe des branches, historique des commits
- [ ] Grp4_GitLab_git-log.txt : export `git log --all --graph --pretty=format:"%h %ad %an %s" --date=short`
